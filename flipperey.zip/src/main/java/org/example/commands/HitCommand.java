package commands;

import elements.FlipperElement;

public interface HitCommand {
    void execute(FlipperElement element);
}
